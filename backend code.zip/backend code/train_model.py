import pandas as pd
import numpy as np
import re
import nltk
from nltk.tokenize import TweetTokenizer
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import pickle
import os

# Download necessary NLTK data
nltk.download('stopwords')
nltk.download('punkt')

# Load dataset
df = pd.read_csv('hatespeech.csv')  # Ensure this path is correct

# Text Preprocessing Function
def preprocess_text(text):
    tokenizer = TweetTokenizer(preserve_case=True)
    stop_words = set(stopwords.words('english'))
    additional_list = ['amp', 'rt', 'u', "can't", 'ur']
    stop_words.update(additional_list)
    
    text = re.sub(r'@\w+', '', text)  # Remove mentions
    text = re.sub(r'http\S+', '', text)  # Remove URLs
    text = re.sub(r'#', '', text)  # Remove hashtags
    text = ' '.join([word for word in tokenizer.tokenize(text) if word.lower() not in stop_words and len(word) > 2])
    
    return text

# Apply preprocessing
df['clean_tweet'] = df['tweet'].apply(preprocess_text)

# Feature extraction (TF-IDF)
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['clean_tweet'])
y = df['label']  # Ensure your dataset has a 'label' column (0 = Not Hate, 1 = Hate Speech)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LogisticRegression()
model.fit(X_train, y_train)

# Evaluate model
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
print(f'Model Accuracy: {accuracy:.2f}')

# Create a directory for models if it doesn't exist
if not os.path.exists('model'):
    os.makedirs('model')

# Save model and vectorizer
with open('model/model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

with open('model/vectorizer.pkl', 'wb') as vec_file:
    pickle.dump(vectorizer, vec_file)

print("Model and vectorizer saved successfully!")
