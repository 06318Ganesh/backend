from flask import Flask, render_template, request, jsonify
import joblib
import re
import string

app = Flask(__name__)  # Corrected Flask initialization

# Load pre-trained model and vectorizer
model = joblib.load('model/model.pkl')
vectorizer = joblib.load('model/vectorizer.pkl')

# Text preprocessing function
def preprocess_text(text):
    text = text.lower()
    text = re.sub(f'[{re.escape(string.punctuation)}]', '', text)  # Remove punctuation
    text = re.sub(r'\d+', '', text)  # Remove digits
    text = re.sub(r'\s+', ' ', text).strip()  # Remove extra spaces
    return text

# Home route: renders the HTML frontend
@app.route('/')
def index():
    return "Hate Speech Detection API Running"

# Predict route: handles AJAX POST requests from the frontend
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        text = data.get('text', '').strip()

        if not text:
            return jsonify({'prediction': 'Undefined'})  # No text provided

        preprocessed = preprocess_text(text)
        vectorized = vectorizer.transform([preprocessed])
        prediction = model.predict(vectorized)[0]

        if prediction == 1:
            result = 'Hate Speech'
        else:
            result = 'Not Hate Speech'

        return jsonify({'prediction': result})

    except Exception as e:
        print("Prediction Error:", e)
        return jsonify({'prediction': 'Error'})  # Handle errors gracefully

if __name__ == '__main__':  # Corrected __name__ check
    app.run(debug=False)
